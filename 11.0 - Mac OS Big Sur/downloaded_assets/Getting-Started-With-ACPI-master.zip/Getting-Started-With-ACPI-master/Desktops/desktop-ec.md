
# Fixing Embedded Controller (Desktop)

## You'll want to go to [SSDT-EC under the Universal tab](/Universal/desktop-ec.md) for the new SSDT-EC page
