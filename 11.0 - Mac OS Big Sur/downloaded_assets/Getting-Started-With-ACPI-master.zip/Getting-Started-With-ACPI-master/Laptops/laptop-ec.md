# Fixing Embedded Controller (Laptop)

## You'll want to go to [SSDT-EC under the Universal tab](/Universal/desktop-ec.md) for the new SSDT-EC page
